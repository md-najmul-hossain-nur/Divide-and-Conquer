#include <iostream>

using namespace std;

long long int power(int X, int Y) {

    if (Y == 0) {
        return 1;
    }


    int mid = Y / 2;
    long long int p = power(X, mid);


    if (Y % 2 == 0) {
        return p * p;
    } else {
        return p * p * X;
    }
}

int main() {
    int X, Y;


    cout << "Enter the base (X): ";
    cin >> X;
    cout << "Enter the exponent (Y): ";
    cin >> Y;


    long long int result = power(X, Y);
    cout << "Result: " << X << "^" << Y << " = " << result << endl;

    return 0;
}
