#include <iostream>

using namespace std;

struct Res {
    int mx, mn;
};


Res findMaxMin(int A[], int i, int j) {


    if (i == j) {
        return {A[i], A[i]};
    } else {

        int mid = (i + j) / 2;

        Res res1 = findMaxMin(A, i, mid);


        Res res2 = findMaxMin(A, mid + 1, j);


        int maxvalue = max(res1.mx, res2.mx);
        int minvalue = min(res1.mn, res2.mn);

        return {maxvalue, minvalue};
    }
}

int main() {

    int N;
    cout << "Enter the size in the array: ";
    cin >> N;

    int A[N];


    cout << "Enter " << N << " numbers: ";
    for (int i = 0; i < N; ++i) {
        cin >> A[i];
    }

    Res result = findMaxMin(A, 0, N - 1);


    cout << "Maximum element: " << result.mx << endl;
    cout << "Minimum element: " << result.mn << endl;

    return 0;
}
